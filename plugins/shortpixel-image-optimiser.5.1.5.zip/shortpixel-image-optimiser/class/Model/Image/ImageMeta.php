<?php
namespace ShortPixel\Model\Image;

// Base Class for ImageMeta
class ImageMeta extends ImageThumbnailMeta
{

  public $errorMessage;
  public $wasConverted = false;


} // class
