<?php
namespace ShortPixel;
?>

  <div id="shortPixelProposeUpgradeShade" class="sp-modal-shade" style="display:none;"></div>

	<div id="shortPixelProposeUpgrade" class="shortpixel-modal shortpixel-hide" style="min-width:650px;margin-left:-305px;">
      <div class="sp-modal-title">
          <button type="button" class="sp-close-upgrade-button" onclick="ShortPixel.closeProposeUpgrade()">&times;</button>
           <?php __('Upgrade your ShortPixel account', 'shortpixel-image-optimiser')  ?>
      </div>
      <div class="sp-modal-body sptw-modal-spinner" style="height:auto;min-height:400px;padding:0;">
      </div>

	</div>
